CMPUT 291 Mini-Project 1 Harbidge, Parhamglst, Wielgus

How to launch: program should already be compiled, so running the project with "./project" should work.
You may also additionally add one argument in the format of a string specifying what database to open. eg: "database.db"

if the program is not compiled, running "make" should create the project executable.
more info can be found in the design document.